﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CustomAprioriAlgorithm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            apriori obj= new apriori();
            /*List<string> list= new List<string>();
            List<string> list1= new List<string>();
            list.Add("A");
            list.Add("B");
            list.Add("C");
            list.Add("D");
            list= obj.objectcross(list);
            *//*list.Remove("A<X>B");
            list.Remove("A<X>C");
            list.Remove("A<X>D");*//*
            list1 =obj.extractlist(list);
            obj.multipleobjects(list,list1);*/
            List<string> transactions= new List<string>();
            /*transactions.Add("Hot Dogs,Buns,Ketchup");
            transactions.Add("Hot Dogs,Buns");
            transactions.Add("Hot Dogs,Coke,Chips");
            transactions.Add("Coke,Chips");
            transactions.Add("Chips,Ketchup");
            transactions.Add("Hot Dogs,Coke,Chips");*/
            transactions.Add("l1,l3,l4");
            transactions.Add("l2,l3,l5,l6");
            transactions.Add("l1,l2,l3,l5");
            transactions.Add("l2,l5");
            transactions.Add("l1,l3,l5");
            List<string> items= new List<string>();
            /*items.Add("Hot Dogs");
            items.Add("Buns");
            items.Add("Ketchup");
            items.Add("Coke");
            items.Add("Chips");*/
            items.Add("l1");
            items.Add("l2");
            items.Add("l3");
            items.Add("l4");
            items.Add("l5");
            items.Add("l6");
            listBox1.DataSource=obj.runaprioribysupport(transactions, items,45f);
            

        }
    }
}
